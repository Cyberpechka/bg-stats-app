console.log('🚀 app.js начал загружаться');
import { FirebaseClient } from './core/firebase-client.js';
import { GameStatsManager } from './modules/stats/GameStatsManager.js';
import { GamesCatalog } from './modules/games/GamesCatalog.js';
import { BGGRatingsService } from './modules/games/BGGRatingsService.js';
import { StorageManager } from './core/storage.js';
import { SPARouter } from './core/router.js';
import { Statistics } from './ui/components/Statistics.js';
import { PlayersManager } from './modules/players/PlayersManager.js';
import { PlayersService } from './modules/players/players.service.js';
import { PlayersTable } from './ui/components/PlayersTable.js';
import { PlayerProfile } from './modules/players/PlayerProfile.js';
import { SessionsManager } from './modules/sessions/SessionsManager.js';
import { SessionsService } from './modules/sessions/sessions.service.js';

class BoardGamesStats {
    constructor() {
        // 🔥 ПЕРВОЕ - ИНИЦИАЛИЗИРУЕМ FIREBASE
        this.firebase = new FirebaseClient();
        
        // 🔥 ВТОРОЕ - ИНИЦИАЛИЗИРУЕМ МЕНЕДЖЕРЫ С FIREBASE
        this.playersManager = new PlayersManager(this.firebase);
        this.playersService = new PlayersService(this.playersManager);
        this.playersTable = new PlayersTable(this.playersManager, this.playersService);
        this.playerProfile = null;
        this.statistics = new Statistics(this.playersManager);

        // Остальные инициализации
        this.storage = new StorageManager();
        this.gameStatsManager = new GameStatsManager(this.storage);
        this.bggRatingsService = new BGGRatingsService();
        
        this.sessionsManager = new SessionsManager(this.firebase, this.storage);
        this.sessionsService = null;
        this.gamesCatalog = null;
        
        this.router = null;
        
        this.init();
    }

    async init() {
        console.log('🚀 Начало инициализации приложения...');
        
        try {
            // 🔥 ШАГ 1: FIREBASE (синхронно)
            console.log('🔥 Инициализация Firebase...');
            const firebaseSuccess = this.firebase.initialize();
            if (!firebaseSuccess) throw new Error('❌ Не удалось инициализировать Firebase');
            console.log('✅ Firebase успешно подключен');

            // 🔥 ШАГ 2: ИГРОКИ (асинхронно)
            console.log('👥 Загрузка игроков из Firebase...');
            await this.playersManager.loadPlayers();
            console.log('✅ Игроки загружены из Firebase');

            // 🔥 ШАГ 3: СЕССИИ (асинхронно)
            console.log('🎪 Инициализация SessionsManager...');
            await this.sessionsManager.init();
            console.log('✅ SessionsManager инициализирован');

            // 🔥 ШАГ 4: ЗАПУСКАЕМ РОУТЕР СРАЗУ - НЕ ЖДЕМ BGG!
            this.setupRouter();
            this.setupGlobalHandlers();
            window.app = this;
            
            console.log('🎉 Приложение готово, запускаем роутер...');
            await this.router.loadRoute(); // 🔥 СТРАНИЦА ПОКАЗЫВАЕТСЯ ЗДЕСЬ!

            // 🔥 ПРЕДЗАГРУЖАЕМ GamesCatalog ДЛЯ БУДУЩИХ СТРАНИЦ
            console.log('🔄 Предзагрузка GamesCatalog...');
            this.gamesCatalog = new GamesCatalog(this.sessionsManager, this.bggRatingsService);
            this.gamesCatalog.init().then(() => {
                console.log('✅ GamesCatalog предзагружен');
            });

            // 🔥 ШАГ 5: BGG РЕЙТИНГИ - ФОНОВАЯ ЗАГРУЗКА (НЕ БЛОКИРУЕМ)
            console.log('🎲 Фоновая загрузка рейтингов BGG...');
            this.bggRatingsService.loadRatings().then(() => {
                console.log('✅ Рейтинги BGG готовы');
                if (this.gamesCatalog) {
                    this.gamesCatalog.enhanceGamesWithBggRatings();
                }
            });
            
        } catch (error) {
            console.error('❌ Критическая ошибка инициализации приложения:', error);
            this.showFatalError('Не удалось загрузить приложение. Пожалуйста, обновите страницу.');
        }
    }
        
    setupRouter() {
        const routes = [
            { path: '/', init: this.initHomePage, title: 'Players Management' },
            { path: '/games', init: () => this.initGamesPage(), title: 'Games' },
            {path: '/sessions', init: () => app.initSessionsPage(), title: 'Sessions'},
            { path: '/stats', init: () => this.initStatsPage(), title: 'Статистика' },
            { path: '/player/:id', init: () => app.initPlayerProfile(), title: 'Профиль игрока' },
            { path: '/about', init: this.initAboutPage, title: 'About' }
        ];

        this.router = new SPARouter(routes, this);
    }

    setupGlobalHandlers() {
        window.addEventListener('beforeunload', () => {
            this.playersManager.saveToStorage();
        });
    }

    // ИНИЦИАЛИЗАЦИЯ СТРАНИЦ
    initHomePage() {
        console.log('🔄 INIT HOME PAGE');
        
        const checkInterval = setInterval(() => {
            const playersTable = document.getElementById('players-table-body');
            if (playersTable) {
                clearInterval(checkInterval);
                this.initializeHomePage();
            }
        }, 50);
    }

    initializeHomePage() {
        this.playersTable.updateTable();
        this.setupPlayerForm();
    }

    setupPlayerForm() {
        const form = document.getElementById('add-player-form');
        if (form) {
            form.onsubmit = (event) => this.handleFormSubmit(event);
        }
    }

    handleFormSubmit(event) {
        event.preventDefault();
        const nameInput = document.getElementById('player-name-input');
        if (!nameInput) return false;

        const nameValue = nameInput.value.trim();
        if (nameValue === '') {
            alert('Пожалуйста, введите имя игрока');
            return false;
        }

        this.playersManager.createPlayer(nameValue);
        nameInput.value = '';
        this.playersTable.updateTable();
        return false;
    }

    async initGamesPage() {
        console.log('🎮 INIT GAMES PAGE');
        
        // 🔥 БЫСТРАЯ ПРОВЕРКА - ЕСЛИ УЖЕ ЗАГРУЖЕНО, ПРОСТО РЕНДЕРИМ
        if (this.gamesCatalog && this.gamesCatalog.isInitialized) {
            console.log('✅ GamesCatalog уже инициализирован - быстрый рендер');
            this.gamesCatalog.renderGames();
            return;
        }
        
        if (!this.gamesCatalog) {
            console.log('🔄 Создаю GamesCatalog...');
            this.gamesCatalog = new GamesCatalog(this.sessionsManager, this.bggRatingsService);
        }
        
        // 🔥 НЕ ЖДЕМ BGG РЕЙТИНГОВ - СТРАНИЦА МОЖЕТ ПОКАЗАТЬСЯ РАНЬШЕ
        await this.gamesCatalog.init();
        console.log('✅ GamesCatalog загружен');
    }

    initAboutPage() {
        console.log('Initializing ABOUT page...');
        const appContainer = document.getElementById('app');
        if (appContainer) {
            appContainer.innerHTML = '<p>About our application</p>';
        }
    }

    initSessionsPage() {
        console.log('🎪 Initializing sessions page...');
        
        // 🔥 ПРОВЕРЯЕМ БЫСТРО - БЕЗ setTimeout
        if (!this.sessionsManager.isInitialized) {
            console.error('❌ SessionsManager не инициализирован');
            return;
        }
        
        console.log('🔍 Создаю SessionsService...');
        
        this.sessionsService = new SessionsService(
            this.sessionsManager, 
            this.gamesCatalog, // 🔥 УЖЕ ДОЛЖЕН БЫТЬ СОЗДАН
            this.playersManager
        );
        
        this.sessionsService.setupSessionForm('add-session-form');
        this.sessionsService.renderSessionsList('sessions-list');
        this.sessionsService.updateStats();
        
        console.log('✅ Страница сессий инициализирована');
    }
    
    initStatsPage() {
        console.log('📊 INIT STATS PAGE');
        setTimeout(() => {
            this.statistics.renderStats('app');
        }, 50);
    }

    initPlayerProfile() {
        console.log('🎯 INIT PLAYER PROFILE');
        
        const playerId = this.getPlayerIdFromURL();
        
        if (!this.playerProfile) {
            this.playerProfile = new PlayerProfile(
                this.playersManager,
                this.sessionsManager, 
                this.gameStatsManager
            );
        }
        
        this.playerProfile.init(playerId);
    }

    getPlayerIdFromURL() {
        const hash = window.location.hash;
        console.log('🔍 [ROUTER] Текущий hash:', hash);
        
        // 🔥 ИЩЕМ КАК ЧИСЛОВЫЕ ТАК И СТРОКОВЫЕ ID
        const match = hash.match(/\/player\/([^\/]+)/);
        
        if (match) {
            const id = match[1];
            console.log('🔍 [ROUTER] Найден ID из URL:', id);
            
            // 🔥 ПРОВЕРЯЕМ, ЧТО ИГРОК С ТАКИМ ID СУЩЕСТВУЕТ
            const player = this.playersManager.getPlayer(id);
            console.log('🔍 [ROUTER] Игрок найден в менеджере:', player);
            
            return id; // 🔥 ВОЗВРАЩАЕМ СТРОКОВЫЙ ID
        }
        
        console.log('🔍 [ROUTER] ID не найден в URL');
        return null;
    }

}

// Запуск приложения
document.addEventListener('DOMContentLoaded', () => {
    new BoardGamesStats();
});