export class PlayerProfile {
    constructor(playersManager, sessionsManager, gameStatsManager) {
        this.playersManager = playersManager;
        this.sessionsManager = sessionsManager;
        this.gameStatsManager = gameStatsManager;
        this.cache = new Map();
        this.currentPlayerName = null;
    }

    init(playerId) {
        console.log('🎯 INIT PLAYER PROFILE for ID:', playerId);
        
        const player = this.playersManager.getPlayerById(playerId);
        
        if (!player) {
            this.showPlayerNotFound();
            return;
        }
        
        this.cache.clear();
        this.currentPlayerName = player.name;
        
        this.updatePlayerProfile(player);
        this.renderAllSessions(player.name);
    }

    // 🆕 МЕТОД ДЛЯ ОТОБРАЖЕНИЯ ВСЕХ СЕССИЙ ИГРОКА
    renderAllSessions(playerName) {
        const container = document.getElementById('all-sessions-container');
        const countElement = document.getElementById('total-sessions-count');
        
        if (!container) {
            console.log('❌ Контейнер для всех сессий не найден');
            return;
        }

        const allSessions = this.sessionsManager.getPlayerSessions(playerName);
        
        // Обновляем счетчик
        if (countElement) {
            countElement.textContent = `${allSessions.length} ${this.getPluralForm(allSessions.length, 'сессия', 'сессии', 'сессий')}`;
        }
        
        if (!allSessions || allSessions.length === 0) {
            container.innerHTML = `
                <div class="no-sessions">
                    <p>🎯 Пока нет сыгранных сессий</p>
                    <p>Этот игрок еще не участвовал в играх</p>
                </div>
            `;
            return;
        }

        // Сортируем по дате (новые сверху)
        const sortedSessions = [...allSessions].sort((a, b) => 
            new Date(b.date) - new Date(a.date)
        );

        const sessionsHTML = sortedSessions.map(session => 
            this.createSessionTableItem(session, playerName)
        ).join('');

        container.innerHTML = sessionsHTML;
        console.log('✅ Отображены все сессии:', allSessions.length);
    }

    // 🆕 СОЗДАЕМ ТАБЛИЧНУЮ КАРТОЧКУ СЕССИИ
    createSessionTableItem(session, currentPlayerName) {
        const scoresTableHTML = this.createSessionScoresTable(session.scores, session.players, session.winner, currentPlayerName);
        
        const isWin = session.winner === currentPlayerName;
        
        return `
            <div class="session-card ${isWin ? 'session-win' : 'session-loss'}" data-session-id="${session.id}">
                <div class="session-card-header">
                    <div class="session-card-title">
                        <span class="session-game-icon">🎮</span>
                        <h3 class="session-game-name">${session.game}</h3>
                        ${isWin ? '<span class="win-indicator">🏆 ПОБЕДА</span>' : ''}
                    </div>
                    <div class="session-card-meta">
                        <span class="session-date">📅 ${new Date(session.date).toLocaleDateString('ru-RU')}</span>
                        ${session.duration ? `<span class="session-duration">⏱ ${session.duration} мин</span>` : ''}
                    </div>
                </div>

                <div class="session-scores-section">
                    ${scoresTableHTML}
                </div>

                ${session.description ? `
                    <div class="session-description">
                        <div class="description-label">📝 Комментарий:</div>
                        <div class="description-text">${session.description}</div>
                    </div>
                ` : ''}
            </div>
        `;
    }

    // 🆕 СОЗДАЕМ ТАБЛИЦУ ОЧКОВ С ВЫДЕЛЕНИЕМ ТЕКУЩЕГО ИГРОКА
    createSessionScoresTable(scores, players, winner, currentPlayerName) {
        if (!scores || Object.keys(scores).length === 0) {
            return '<div class="no-scores">Нет данных об очках</div>';
        }

        const maxRounds = Math.max(...Object.values(scores).map(playerScores => playerScores.length));
        
        let tableHTML = `
            <div class="session-scores-table-container">
                <table class="session-scores-table">
                    <thead>
                        <tr>
                            <th class="round-col">Раунд</th>
                            ${players.map(player => {
                                const isWinner = player === winner;
                                const isCurrent = player === currentPlayerName;
                                let className = '';
                                if (isWinner) className += 'winner-player';
                                if (isCurrent) className += ' current-player';
                                return `<th class="player-col ${className}">${player}</th>`;
                            }).join('')}
                        </tr>
                    </thead>
                    <tbody>
        `;

        for (let round = 0; round < maxRounds; round++) {
            tableHTML += `
                <tr>
                    <td class="round-number">${round + 1}</td>
                    ${players.map(player => {
                        const playerScores = scores[player] || [];
                        const score = round < playerScores.length ? playerScores[round] : '-';
                        const isCurrent = player === currentPlayerName;
                        return `<td class="score-cell ${isCurrent ? 'current-player' : ''}">${score}</td>`;
                    }).join('')}
                </tr>
            `;
        }

        tableHTML += `
                <tr class="total-row">
                    <td class="total-label"><strong>ИТОГО</strong></td>
                    ${players.map(player => {
                        const playerScores = scores[player] || [];
                        const total = playerScores.reduce((sum, score) => sum + (parseInt(score) || 0), 0);
                        const isWinner = player === winner;
                        const isCurrent = player === currentPlayerName;
                        let className = '';
                        if (isWinner) className += 'winner-total';
                        if (isCurrent) className += ' current-player';
                        return `
                            <td class="total-cell ${className}">
                                ${isWinner ? '🏆 ' : ''}${total}
                            </td>
                        `;
                    }).join('')}
                </tr>
            </tbody>
        </table>
    </div>`;

        return tableHTML;
    }

    // ОСТАЛЬНЫЕ СУЩЕСТВУЮЩИЕ МЕТОДЫ БЕЗ ИЗМЕНЕНИЙ
    updatePlayerProfile(player) {
        document.getElementById('player-name').textContent = player.name;
        document.getElementById('breadcrumb-player').textContent = player.name;
        
        const stats = this.sessionsManager.getPlayerDetailedStats(player.name);
        
        // 🆕 ПЕРЕДАЕМ ИМЯ ИГРОКА ДЛЯ ПРАВИЛЬНОГО ПОДСЧЕТА
        this.renderPlayerStats(stats, player.name);
        
        this.renderPlayerMeta(player);
        this.renderFavoriteGames(player.name, stats.gameStats);
        this.renderGameStats(stats.gameStats);
    }

    // 🆕 ОБНОВЛЕННЫЙ МЕТОД ДЛЯ ЛЮБИМЫХ ИГР (НЕ ИСПОЛЬЗУЕТ GameStatsManager)
    renderFavoriteGames(playerName, gameStats) {
        const container = document.getElementById('favorite-games');
        
        if (!gameStats || Object.keys(gameStats).length === 0) {
            container.innerHTML = '<div class="no-data">Нет данных об играх</div>';
            return;
        }
        
        // 🆕 СОРТИРУЕМ ИГРЫ ПО КОЛИЧЕСТВУ ПАРТИЙ И БЕРЕМ ТОП-5
        const favoriteGames = Object.entries(gameStats)
            .map(([gameName, stats]) => ({
                name: gameName,
                plays: stats.plays,
                wins: stats.wins,
                winRate: stats.plays > 0 ? Math.round((stats.wins / stats.plays) * 100) : 0
            }))
            .sort((a, b) => b.plays - a.plays)
            .slice(0, 5); // Топ-5 игр
        
        container.innerHTML = favoriteGames.map(game => `
            <div class="favorite-game-item">
                <div class="game-name">${game.name}</div>
                <div class="game-stats">
                    <span class="game-plays">${game.plays} партий</span>
                    <span class="game-wins">${game.wins} побед</span>
                    <span class="game-winrate">${game.winRate}%</span>
                </div>
            </div>
        `).join('');
        
        console.log('🎮 Обновлены любимые игры:', favoriteGames);
    }

    renderGameStats(gameStats) {
        const container = document.getElementById('detailed-game-stats');
        if (!container) return;
        
        if (Object.keys(gameStats).length === 0) {
            container.innerHTML = '<div class="no-data">Нет статистики по играм</div>';
            return;
        }
        
        // 🆕 СОРТИРУЕМ ПО КОЛИЧЕСТВУ ПАРТИЙ (САМЫЕ ПОПУЛЯРНЫЕ СВЕРХУ)
        const sortedGames = Object.entries(gameStats)
            .sort(([,a], [,b]) => b.plays - a.plays);
        
        container.innerHTML = sortedGames.map(([gameName, stats]) => {
            const winRate = stats.plays > 0 ? Math.round((stats.wins / stats.plays) * 100) : 0;
            return `
                <div class="game-stat-item">
                    <div class="game-name">🎮 ${gameName}</div>
                    <div class="game-details">
                        <span class="game-plays">${stats.plays} ${this.getPluralForm(stats.plays, 'игра', 'игры', 'игр')}</span>
                        <span class="game-wins">${stats.wins} ${this.getPluralForm(stats.wins, 'победа', 'победы', 'побед')}</span>
                        <span class="game-winrate">${winRate}% побед</span>
                    </div>
                </div>
            `;
        }).join('');
    }

    // 🆕 ВСПОМОГАТЕЛЬНЫЙ МЕТОД ДЛЯ СКЛОНЕНИЯ СЛОВ
    getPluralForm(number, one, two, five) {
        let n = Math.abs(number);
        n %= 100;
        if (n >= 5 && n <= 20) {
            return five;
        }
        n %= 10;
        if (n === 1) {
            return one;
        }
        if (n >= 2 && n <= 4) {
            return two;
        }
        return five;
    }

    formatTime(minutes) {
        const hours = Math.floor(minutes / 60);
        const mins = minutes % 60;
        return hours > 0 ? `${hours}ч ${mins}м` : `${mins}м`;
    }

    renderPlayerStats(stats, playerName) {
        console.log('🔍 [DEBUG] renderPlayerStats:', { stats, playerName });
        
        document.getElementById('player-total-games').textContent = stats.totalGames;
        document.getElementById('player-total-wins').textContent = stats.wins;
        document.getElementById('player-win-rate').textContent = stats.winRate + '%';
        document.getElementById('player-sessions').textContent = stats.totalGames + ' сессий';
        
        document.getElementById('player-total-time').textContent = this.formatTime(stats.totalTime);
        document.getElementById('player-average-time').textContent = this.formatTime(stats.averageTime);
        document.getElementById('player-longest-game').textContent = this.formatTime(stats.longestGame);
        document.getElementById('player-current-streak').textContent = stats.currentStreak;
        
        // 🆕 ПРАВИЛЬНЫЙ ПОДСЧЕТ УНИКАЛЬНЫХ ИГР
        const uniqueGames = stats.gameStats ? Object.keys(stats.gameStats).length : 0;
        document.getElementById('player-unique-games').textContent = uniqueGames;
        
        // 🆕 ОБНОВЛЯЕМ ЛЮБИМУЮ ИГРУ
        const favoriteGameElement = document.getElementById('favorite-game');
        if (favoriteGameElement) {
            favoriteGameElement.textContent = stats.favoriteGame || '—';
        }
    }

    renderPlayerMeta(player) {
        const joinedDate = player.createdAt ? new Date(player.createdAt).toLocaleDateString('ru-RU') : 'неизвестно';
        document.getElementById('player-joined').textContent = `Участник с ${joinedDate}`;
    }

    showPlayerNotFound() {
        const appContainer = document.getElementById('app');
        appContainer.innerHTML = `
            <div style="padding: 2rem; text-align: center;">
                <h1>😕 Игрок не найден</h1>
                <p>Такого игрока не существует</p>
                <a href="#/" class="btn btn-primary">← Назад к игрокам</a>
            </div>
        `;
    }

    // 🆕 МЕТОД ДЛЯ ПРИНУДИТЕЛЬНОГО ОБНОВЛЕНИЯ ПРОФИЛЯ
    refreshProfile(playerId) {
        console.log('🔄 Принудительное обновление профиля игрока:', playerId);
        this.cache.clear();
        this.init(playerId);
    }
}