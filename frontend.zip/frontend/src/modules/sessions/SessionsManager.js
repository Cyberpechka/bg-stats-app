import { StorageManager } from '../../core/storage.js';

export class SessionsManager {
    constructor(firebaseClient, storage) {
        console.log('📦 SessionsManager создается, firebase:', !!firebaseClient);
        this.firebase = firebaseClient;
        this.storage = storage;
        this.sessions = [];
        this.isInitialized = false;
    }

    async init() {
        console.log('🔄 SessionsManager инициализация...');
        
        if (!this.firebase || !this.firebase.isInitialized) {
            throw new Error('❌ Firebase не инициализирован для SessionsManager');
        }
        
        try {
            await this.loadSessions();
            this.isInitialized = true;
            console.log('✅ SessionsManager успешно инициализирован, сессий:', this.sessions.length);
        } catch (error) {
            console.error('❌ Ошибка инициализации SessionsManager:', error);
            this.isInitialized = false;
            throw error;
        }
    }

    async loadSessions() {
        // 🔥 ВСЕГДА ПЫТАЕМСЯ ИСПОЛЬЗОВАТЬ FIREBASE ПЕРВЫМ
        if (!this.firebase || !this.firebase.isInitialized) {
            console.warn('⚠️ Firebase недоступен, используем localStorage');
            const result = this.storage.get('gameSessions', []);
            this.sessions = result;
            return result;
        }
        
        try {
            const firebaseSessions = await this.firebase.getSessions();
            
            // 🔥 ЕСЛИ В FIREBASE ЕСТЬ ДАННЫЕ - ИСПОЛЬЗУЕМ ИХ
            if (firebaseSessions && firebaseSessions.length > 0) {
                console.log('🔥 Загружены сессии из Firebase:', firebaseSessions.length);
                this.sessions = firebaseSessions;
                this.saveSessions(); // Синхронизируем localStorage
            } 
            // 🔥 ЕСЛИ FIREBASE ПУСТОЙ - ТОЖЕ ИСПОЛЬЗУЕМ ЕГО (ПУСТОЙ МАССИВ)
            else {
                console.log('📁 Firebase пуст - используем пустой массив');
                this.sessions = [];
                this.saveSessions(); // Очищаем localStorage
            }
            
            return this.sessions;
            
        } catch (error) {
            console.error('❌ Ошибка загрузки сессий:', error);
            // 🔄 FALLBACK: используем localStorage
            const result = this.storage.get('gameSessions', []);
            this.sessions = result;
            return result;
        }
    }

    saveSessions() {
        this.storage.set('gameSessions', this.sessions);
    }

    async migrateToFirebase() {
        console.log('🚚 Миграция сессий в Firebase...');
        try {
            for (const session of this.sessions) {
                await this.firebase.addSession(session);
            }
            
            // 🔥 ОЧИЩАЕМ LOCALSTORAGE ПОСЛЕ УСПЕШНОЙ МИГРАЦИИ
            this.storage.set('gameSessions', []);
            console.log('✅ Сессии мигрированы в Firebase, localStorage очищен');
            
        } catch (error) {
            console.error('❌ Ошибка миграции сессий в Firebase:', error);
        }
    }

    updateUI() {
        if (window.app && window.app.sessionsService) {
            console.log('🔍 [SESSIONS] Обновляем UI сессий');
            window.app.sessionsService.renderSessionsList('sessions-list');
            window.app.sessionsService.updateStats();
        }
    }

    async addSession(sessionData) {
        // 🆕 ОБРАБАТЫВАЕМ НОВУЮ СТРУКТУРУ ОЧКОВ
        const processedSession = this.processSessionData(sessionData);
        
        const newSession = {
            ...processedSession,
            createdAt: new Date().toISOString()
        };
        
        if (!this.firebase || !this.firebase.isInitialized) {
            console.warn('⚠️ Firebase недоступен, создаем сессию локально');
            this.sessions.push(newSession);
            this.saveSessions();
            this.updateUI();
            return newSession;
        }
        
        try {
            const createdSession = await this.firebase.addSession(newSession);
            await this.loadSessions();
            console.log('✅ Сессия добавлена в Firebase:', newSession.game);
            return createdSession;
            
        } catch (error) {
            console.error('❌ Ошибка добавления сессии в Firebase:', error);
            this.sessions.push(newSession);
            this.saveSessions();
            this.updateUI();
            console.log('📁 Сессия создана локально (fallback)');
            return newSession;
        }
    }

    // 🆕 МЕТОД ДЛЯ ОБРАБОТКИ СТРУКТУРЫ ОЧКОВ
    processSessionData(sessionData) {
        const processed = { 
            ...sessionData,
            // 🆕 ДОБАВЛЯЕМ ПО УМОЛЧАНИЮ - СТАРЫЕ СЕССИИ НЕ СЛОМАЮТСЯ
            gameType: sessionData.gameType || "scoring",
            isTeamGame: sessionData.isTeamGame || false,
            teams: sessionData.teams || null
        };
        
        // 🆕 ОБРАБОТКА РАЗНЫХ ТИПОВ
        if (processed.gameType === "scoring") {
            // СУЩЕСТВУЮЩАЯ ЛОГИКА ПОДСЧЕТА ОЧКОВ
            if (!processed.totalScores && processed.scores) {
                processed.totalScores = {};
                Object.entries(processed.scores).forEach(([player, scores]) => {
                    processed.totalScores[player] = Array.isArray(scores) 
                        ? scores.reduce((sum, score) => sum + (score || 0), 0)
                        : scores || 0;
                });
            }
            
            // 🆕 АВТОМАТИЧЕСКИЙ ПОБЕДИТЕЛЬ ДЛЯ SCORING
            if (!processed.winner && processed.totalScores) {
                let maxScore = -1;
                let winner = '';
                Object.entries(processed.totalScores).forEach(([player, totalScore]) => {
                    if (totalScore > maxScore) {
                        maxScore = totalScore;
                        winner = player;
                    }
                });
                if (winner) processed.winner = winner;
            }
        }
        // 🆕 ДЛЯ NON_SCORING - победитель должен быть указан вручную
        // пока ничего не делаем
        
        return processed;
    }

    async deleteSession(sessionId) {
        console.log('🗑️ Пытаемся удалить сессию ID:', sessionId);
        console.log('🔍 [DEBUG] Тип sessionId:', typeof sessionId);
        console.log('🔍 [DEBUG] Длина sessionId:', sessionId.length);
        
        // 🔥 ДЕТАЛЬНАЯ ПРОВЕРКА КАЖДОЙ СЕССИИ
        this.sessions.forEach((session, index) => {
            console.log(`🔍 [DEBUG] Сессия ${index}:`, {
                id: session.id,
                'id type': typeof session.id,
                'id length': session.id?.length,
                'sessionId === id': sessionId === session.id,
                'sessionId == id': sessionId == session.id,
                'JSON equal': JSON.stringify(sessionId) === JSON.stringify(session.id)
            });
        });

        const sessionIndex = this.sessions.findIndex(session => {
            const isMatch = session.id === sessionId;
            console.log(`🔍 [COMPARE] ${session.id} === ${sessionId} -> ${isMatch}`);
            return isMatch;
        });
        
        if (sessionIndex === -1) {
            console.error('❌ Сессия не найдена ID:', sessionId);
            return false;
        }

        // 🔥 ПРОВЕРЯЕМ FIREBASE
        if (!this.firebase || !this.firebase.isInitialized) {
            console.warn('⚠️ Firebase недоступен, удаляем сессию локально');
            this.sessions.splice(sessionIndex, 1);
            this.saveSessions();
            this.updateUI();
            return true;
        }

        try {
            console.log('🔍 [DEBUG] Удаляем из Firebase ID:', sessionId);
            await this.firebase.deleteSession(sessionId);
            
            console.log('🔍 [DEBUG] Перезагружаем сессии из Firebase...');
            await this.loadSessions();
            
            // 🔥 ОБНОВЛЯЕМ LOCALSTORAGE АКТУАЛЬНЫМИ ДАННЫМИ ИЗ FIREBASE
            this.saveSessions();
            
            console.log('✅ Сессия удалена из Firebase и localStorage синхронизирован');
            return true;
            
        } catch (error) {
            console.error('❌ Ошибка удаления сессии из Firebase:', error);
            
            // 🔄 FALLBACK: удаляем локально
            this.sessions.splice(sessionIndex, 1);
            this.saveSessions();
            this.updateUI();
            
            console.log('📁 Сессия удалена локально (fallback)');
            return true;
        }
    }

    getSessions() {
        return this.sessions;
    }

    getSession(sessionId) {
        return this.sessions.find(session => session.id === sessionId);
    }

    getSessionsByGame(gameName) {
        return this.sessions.filter(session => session.game === gameName);
    }

    getPlayerSessions(playerName) {
        return this.sessions.filter(session => 
            session.players.includes(playerName)
        );
    }

    getPlayerStats(playerName) {
        const playerSessions = this.getPlayerSessions(playerName);
        const totalGames = playerSessions.length;
        const wins = playerSessions.filter(session => session.winner === playerName).length;
        const winRate = totalGames > 0 ? Math.round((wins / totalGames) * 100) : 0;
        
        return {
            totalGames,
            wins,
            winRate,
            favoriteGame: this.getFavoriteGame(playerName)
        };
    }

    getPlayerRecentSessions(playerName, limit = 5) {
        const playerSessions = this.getPlayerSessions(playerName);
        return playerSessions
            .sort((a, b) => new Date(b.date) - new Date(a.date))
            .slice(0, limit);
    }

    getFavoriteGame(playerName) {
        const playerSessions = this.getPlayerSessions(playerName);
        
        if (playerSessions.length === 0) return null;
        
        const gameCounts = {};
        playerSessions.forEach(session => {
            gameCounts[session.game] = (gameCounts[session.game] || 0) + 1;
        });
        
        const favoriteGame = Object.entries(gameCounts)
            .sort(([,a], [,b]) => b - a)[0];
        
        return favoriteGame ? favoriteGame[0] : null;
    }

    getPlayerDetailedStats(playerName) {
        const playerSessions = this.getPlayerSessions(playerName);
        const totalGames = playerSessions.length;
        const wins = playerSessions.filter(session => session.winner === playerName).length;
        const winRate = totalGames > 0 ? Math.round((wins / totalGames) * 100) : 0;
        
        const totalTime = playerSessions.reduce((sum, session) => sum + (session.duration || 0), 0);
        
        const gameStats = {};
        playerSessions.forEach(session => {
            if (!gameStats[session.game]) {
                gameStats[session.game] = { plays: 0, wins: 0 };
            }
            gameStats[session.game].plays++;
            if (session.winner === playerName) {
                gameStats[session.game].wins++;
            }
        });
        
        const durations = playerSessions.map(s => s.duration).filter(Boolean);
        const longestGame = durations.length > 0 ? Math.max(...durations) : 0;
        const shortestGame = durations.length > 0 ? Math.min(...durations) : 0;
        
        const lastSession = playerSessions.sort((a, b) => new Date(b.date) - new Date(a.date))[0];
        
        return {
            totalGames,
            wins,
            winRate,
            totalTime,
            averageTime: totalGames > 0 ? Math.round(totalTime / totalGames) : 0,
            longestGame,
            shortestGame,
            favoriteGame: this.getFavoriteGame(playerName),
            gameStats,
            lastPlay: lastSession ? new Date(lastSession.date) : null,
            currentStreak: this.getCurrentStreak(playerSessions, playerName)
        };
    }

    getCurrentStreak(playerSessions, playerName) {
        const sortedSessions = playerSessions.sort((a, b) => new Date(b.date) - new Date(a.date));
        
        let streak = 0;
        for (const session of sortedSessions) {
            if (session.winner === playerName) {
                streak++;
            } else {
                break;
            }
        }
        return streak;
    }

    getPlayerUniqueGames(playerName) {
        const playerSessions = this.getPlayerSessions(playerName);
        const uniqueGames = new Set();
        
        playerSessions.forEach(session => {
            if (session.game) {
                uniqueGames.add(session.game);
            }
        });
        
        return uniqueGames.size;
    }
}