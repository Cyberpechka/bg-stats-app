// src/modules/stats/GameStatsManager.js
export class GameStatsManager {
    constructor(storageManager) {
        this.storage = storageManager;
        this.gameStats = this.loadGameStats();
        console.log('📊 GameStatsManager создан, загружено статистик:', Object.keys(this.gameStats).length);
    }

    loadGameStats() {
        const stats = this.storage.get('gameStatistics', {});
        console.log('📊 Загружена статистика игр:', stats);
        return stats;
    }

    saveGameStats() {
        this.storage.set('gameStatistics', this.gameStats);
        console.log('💾 Статистика игр сохранена');
    }

    // Получить статистику по названию игры
    getGameStats(gameName) {
        console.log('🔍 ПОИСК СТАТИСТИКИ ДЛЯ ИГРЫ:', gameName);
        console.log('🔍 ВСЕ КЛЮЧИ В gameStats:', Object.keys(this.gameStats));
        console.log('🔍 ВСЯ СТАТИСТИКА:', this.gameStats);
        
        // Проверяем прямое совпадение
        if (this.gameStats[gameName]) {
            console.log('✅ Найдено прямое совпадение');
            return this.gameStats[gameName];
        }
        
        // Проверяем все возможные варианты
        const foundKey = Object.keys(this.gameStats).find(key => {
            const match = key === gameName;
            console.log(`🔍 Сравниваем: "${key}" === "${gameName}" = ${match}`);
            return match;
        });
        
        console.log('🔍 Найденный ключ:', foundKey);
        
        if (foundKey) {
            console.log('✅ Найдено по ключу:', foundKey);
            return this.gameStats[foundKey];
        }
        
        console.log('❌ Статистика не найдена');
        return null;
    }

    // Обновить статистику на основе сессии
    updateGameStats(session) {
        const gameName = session.game;
        
        // Если статистики для игры нет - создаем
        if (!this.gameStats[gameName]) {
            this.gameStats[gameName] = this.createEmptyGameStats();
        }

        const stats = this.gameStats[gameName];
        
        // Обновляем базовую статистику
        stats.totalPlays = (stats.totalPlays || 0) + 1;
        
        // Обновляем даты
        const sessionDate = new Date(session.date);
        if (!stats.firstPlay || sessionDate < new Date(stats.firstPlay)) {
            stats.firstPlay = session.date;
        }
        if (!stats.lastPlay || sessionDate > new Date(stats.lastPlay)) {
            stats.lastPlay = session.date;
        }

        // Обновляем длительности
        if (!stats.minDuration || session.duration < stats.minDuration) {
            stats.minDuration = session.duration;
        }
        if (!stats.maxDuration || session.duration > stats.maxDuration) {
            stats.maxDuration = session.duration;
        }

        // Обновляем статистику игроков
        this.updatePlayersStats(stats, session);
        
        // Обновляем очки
        this.updateScoresStats(stats, session);

        this.saveGameStats();
        console.log('🔄 Обновлена статистика для игры:', gameName, stats);
    }

    updatePlayersStats(stats, session) {
        if (!stats.players) {
            stats.players = {};
        }

        // Обновляем всех участников сессии
        session.players.forEach(playerName => {
            if (!stats.players[playerName]) {
                stats.players[playerName] = {
                    totalGames: 0,
                    wins: 0,
                    bestScore: 0
                };
            }
            stats.players[playerName].totalGames++;
        });

        // Обновляем победителя
        const winner = session.winner;
        if (winner && stats.players[winner]) {
            stats.players[winner].wins++;
        }
    }

    updateScoresStats(stats, session) {
        if (!session.scores) return;

        Object.entries(session.scores).forEach(([playerName, score]) => {
            if (stats.players[playerName]) {
                if (score > stats.players[playerName].bestScore) {
                    stats.players[playerName].bestScore = score;
                }
            }
        });
    }

    createEmptyGameStats() {
        return {
            totalPlays: 0,
            minDuration: null,
            maxDuration: null,
            firstPlay: null,
            lastPlay: null,
            players: {}
        };
    }

    // Получить топ игроков для игры
    getTopPlayers(gameName, limit = 3) {
        const stats = this.getGameStats(gameName);
        if (!stats || !stats.players) return [];

        return Object.entries(stats.players)
            .map(([name, data]) => ({
                name,
                wins: data.wins,
                total: data.totalGames,
                percentage: data.totalGames > 0 ? Math.round((data.wins / data.totalGames) * 100) : 0,
                bestScore: data.bestScore
            }))
            .sort((a, b) => b.wins - a.wins)
            .slice(0, limit);
    }

    // Получить лучший счет для игры
    getBestScore(gameName) {
        const stats = this.getGameStats(gameName);
        if (!stats || !stats.players) return null;

        let bestScore = 0;
        let bestPlayer = '';

        Object.entries(stats.players).forEach(([name, data]) => {
            if (data.bestScore > bestScore) {
                bestScore = data.bestScore;
                bestPlayer = name;
            }
        });

        return bestScore > 0 ? { player: bestPlayer, score: bestScore } : null;
    }

    // Получить все игры, в которые играли
    getPlayedGames() {
        return Object.keys(this.gameStats).filter(gameName => 
            this.gameStats[gameName].totalPlays > 0
        );
    }
    findGameStats(gameName) {
        // Прямое совпадение
        if (this.gameStats[gameName]) {
            return this.gameStats[gameName];
        }
        
        // Поиск по частичному совпадению (на случай различий в регистре/пробелах)
        const normalizedSearch = gameName.toLowerCase().trim();
        const foundKey = Object.keys(this.gameStats).find(key => 
            key.toLowerCase().trim() === normalizedSearch
        );
        
        console.log('🔍 Поиск статистики:', {
            ищем: gameName,
            нормализовано: normalizedSearch,
            найдено: foundKey
        });
        
        return foundKey ? this.gameStats[foundKey] : null;
    }

    getPlayerFavoriteGames(playerName, limit = 5) {
        const playerGames = [];
        
        Object.entries(this.gameStats).forEach(([gameName, stats]) => {
            if (stats.players && stats.players[playerName]) {
                playerGames.push({
                    name: gameName,
                    plays: stats.players[playerName].totalGames
                });
            }
        });
        
        return playerGames
            .sort((a, b) => b.plays - a.plays)
            .slice(0, limit);
    }

}